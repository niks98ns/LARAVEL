@extends('layouts.app')

@section('content')
    <a href="/posts" class="btn btn-default">Go Back</a>
    <h1>{{$post->title}}</h1>
    <img style="width:20%" src="/storage/cover_images/{{$post->cover_image}}">
    <br><br>
    <div>
        {!!$post->body!!}
    </div>
    <hr>
        <small>written on{{$post->created_at}} by {{$post->user->name}}</small>
    <hr/>

  
            <a href="/posts/{{$post->id}}/edit" class="btn btn-default" >Edit</a>

            
            <div classs="nik"  style="margin-right:90%; margin-top:-37px;">
                
            {!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right' ])!!} 
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
                
            {!!Form::close()!!}
  </div>
<div class="col-md-9">
  <h1>Create Comment</h1>          
    {!! Form::open(['action' => 'CommentController@store', 'method' => 'POST']) !!}
        <div class="form-group">
            {{Form::label('body', 'Comment')}}
            {{Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Comment'])}}
            {{Form::hidden('post_id', $post->id)}}
        </div>
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
    
    {!! Form::close() !!}
    </div>
  {{--Answer/comment--}}
<div class="col-md-8 comment-list" style="float:left; width:100%;">

    @foreach($post->comments as $comment)
        <h4>{{$comment->body}}</h4>
        <lead>{{$comment->user->name}}</lead>   
    
        <div class="actions"> 

            {{--<a href="{{route)('post.edit',$post->id)}}" class="btn btn-info btn-xs">Edit</a>--}}

            <a classs="btn btn-primary btn-xs" data toggle="model" href="#{{$comment->id}}">Edit</a>
            <div class="maodal fade" id="{{$comment->id}}">
                <div class="modal-dialog">
                    <div class="modal-content">
                            <div class="modal-content">
                            <button type="submit" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> 
                            <h4 class="modal-title">Modal Title</h4> 
                        </div>
                        <div class="modal-body">
                            <div class="comment-form">
                                    {!! Form::open(['action' => ['CommentController@update', $comment->id], 'method' => 'POST']) !!}
                                    {{-- <form action="" method="post" role="inline-it"> --}}
                                            {{csrf_field()}}
                                            {{method_field('Put')}}
                                            <legend>Edit Comment</legend>
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="body"  placeholder="Input" value="{{$comment->body}}">
                                            </div> 
                                            <button type="submit" class="btn btn-primary">Comment</button>  
                                    {{-- </form>  --}}
                                    {!! Form::close() !!} 
                            </div>
                            
                        </div>
                        <div classs="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss=""modal>Close</button>
                                <button type="button" class="btn btn-primary">Save Changes</button> 
                        </div>
                    </div>
                </div>
            </div>

            {{--//delete form--}}
            <div classs="nik"  style="margin-right:90%; margin-top:-37px;margin-bottom:-8%;">
                
                {!!Form::open(['action' => ['CommentController@destroy', $comment->id], 'method' => 'POST', 'class' => 'pull-right' ])!!} 
                    {{Form::hidden('_method', 'DELETE')}}
                    {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
                    
                {!!Form::close()!!}
            </div>
            
        </div>
    @endforeach

</div>
<br><br>


@endsection
