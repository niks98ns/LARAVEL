<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/index', 'pagesController@index'); 
Route::get('/about', 'pagesController@about');
Route::get('/services', 'pagesController@services');
Route::get('/contact', 'pagesController@contact');

Route::resource('posts', 'PostsController');//->middleware('auth'); 
Auth::routes();

Route::get('/dashboard', 'DashboardController@index');

Route::resource('comment', 'CommentController',['only'=>['update','destroy','store']]); 

// Route::post("comment/create/{post}",'CommentController@addPostComment')->name('postcomment.store');




