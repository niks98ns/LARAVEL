

<!doctype html>
<html lang=<?php echo e(config('app.locale' )); ?>>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IF=edge">
        <meta name="viewport" content="width=device-width, initial-scale-1">
        <title><?php echo e(config('app.name', 'LSAPP')); ?></title>
    </head>
    <body>
            <h1>About</h1>
            <p>This is the about page</p>
    </body>
</html>