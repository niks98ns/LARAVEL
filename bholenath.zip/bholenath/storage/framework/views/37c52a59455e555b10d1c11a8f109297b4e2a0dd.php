<?php $__env->startSection('content'); ?>
    <a href="/posts" class="btn btn-default">Go Back</a>
    <h1><?php echo e($post->title); ?></h1>
    <img style="width:20%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
    <br><br>
    <div>
        <?php echo $post->body; ?>

    </div>
    <hr>
        <small>written on<?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
    <hr/>

  
            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-default" >Edit</a>

            
            <div classs="nik"  style="margin-right:90%; margin-top:-37px;">
                
            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right' ]); ?> 
                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                
            <?php echo Form::close(); ?>

  </div>
<div class="col-md-9">
  <h1>Create Comment</h1>          
    <?php echo Form::open(['action' => 'CommentController@store', 'method' => 'POST']); ?>

        <div class="form-group">
            <?php echo e(Form::label('body', 'Comment')); ?>

            <?php echo e(Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Comment'])); ?>

            <?php echo e(Form::hidden('post_id', $post->id)); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    
    <?php echo Form::close(); ?>

    </div>
  
<div class="col-md-8 comment-list" style="float:left; width:100%;">

    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h4><?php echo e($comment->body); ?></h4>
        <lead><?php echo e($comment->user->name); ?></lead>   
    
        <div class="actions">

            

            <a classs="btn btn-primary btn-xs" data toggle="model" href="#<?php echo e($comment->id); ?>">Edit</a>
            <div class="maodal fade" id="<?php echo e($comment->id); ?>">
                <div class="modal-dialog">
                    <div class="modal-content">
                            <div class="modal-content">
                            <button type="submit" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> 
                            <h4 class="modal-title">Modal Title</h4> 
                        </div>
                        <div class="modal-body">
                            <div class="comment-form">
                                    <?php echo Form::open(['action' => ['CommentController@update', $comment->id], 'method' => 'POST']); ?>

                                    
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('Put')); ?>

                                            <legend>Edit Comment</legend>
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="body"  placeholder="Input" value="<?php echo e($comment->body); ?>">
                                            </div> 
                                            <button type="submit" class="btn btn-primary">Comment</button>  
                                    
                                    <?php echo Form::close(); ?> 
                            </div>
                            
                        </div>
                        <div classs="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss=""modal>Close</button>
                                <button type="button" class="btn btn-primary">Save Changes</button> 
                        </div>
                    </div>
                </div>
            </div>

            
            <div classs="nik"  style="margin-right:90%; margin-top:-37px;margin-bottom:-8%;">
                
                <?php echo Form::open(['action' => ['CommentController@destroy', $comment->id], 'method' => 'POST', 'class' => 'pull-right' ]); ?> 
                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                    
                <?php echo Form::close(); ?>

            </div>
            
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<br><br>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>