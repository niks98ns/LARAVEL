<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Student;

class Session extends Model
{
    protected $fillable =[
        'student_id',
        'admission_year',
        'starting_year'
        
    ];

    public function student()
    {
        return $this->belongsTo('App\Student');
        
    }
     
    
}
