<?php $__env->startSection('content'); ?>
<div class= "container">

<!-- Button trigger modal -->

<a href="" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Add Students </a>

<table id="data_table" class ="table table-striped table-responsive">

  <thead>
    <tr>
          <th>ID</th>
          <th>IMAGE </th>
          <th>ROLL-NUMBER</th>
          <th>BIRTH YEAR</th>
          <th> FULL-NAME </th>
          <th>SEMESTER-INFORMATION</th>
          <th>ADDRESS</th>
          <th>CITY</th>
          <th>PINCODE</th>
          <th>DEPARTMENT</th>
          <th>ADDMISSION-YEAR </th>
          <th>PASSING-YEAR </th>
        
        <th colsapn = 2><center>Action</center> </th> 
    </tr>
  </thead>
  <tbody>

<!-- <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
       

<?php $image = $student->student_profile->cover_image; ?>


    <tr>
          <td><?php echo e($student->id); ?></td>

          <td><img src='<?php echo e(asset("storage/$image")); ?>'></td>

          <td><?php echo e($student->student_profile->roll_number); ?></td>

          <td><?php echo e($student->student_profile->birth_year); ?></td>
        
          <td><?php echo e($student->FullName); ?></td>
          <td><?php echo e($student->SemesterInformation); ?></td>
          <td><?php echo e($student->student_profile->address); ?></td>
          <td><?php echo e($student->student_profile->city); ?></td>
          <td><?php echo e($student->student_profile->pincode); ?></td>  
          <td><?php echo e($student->department->department_name); ?></td>
          <td><?php echo e($student->session->admission_year); ?></td>
           <td><?php echo e($student->session->passing_year); ?></td> -->
         
          
      <!-- code for edit button for update the data in the database--> 
           <!-- <td>
            <a href="#" data-id="<?php echo e($student->id); ?>" class="btn btn-success edit_student">Edit</a>
          </td>  -->

<!-- code for delete button for delete the data in the database -->

           <!-- <td>
            <button class="btn btn-danger delete_record" data-id="<?php echo e($student->id); ?>">Delete</button>
          <td> -->
    </tr> 
  
<!-- <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  -->

  </tbody>
</table>

<!--Start Add  Modal -->

<?php echo $__env->make('students.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->make('students.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<script type="text/javascript">

$(document).ready(function(){
  $('.delete_record').click(function(e){
  var choice = confirm('Do you really want to delete this record?');
  if(choice === true) {
    e.preventDefault();
  var cutomrurl ="<?php echo e(URL::to('students/deleteStudent')); ?>";
  $this = $(this)
  var id = $this.data('id');
  $.ajax({
      url:cutomrurl+'/'+id,
      type:'GET',
      dataType: "JSON",
      success:function(response){
        // console.log(response);
        if(response.status == true) {
          $this.parent().parent('tr').remove();
        }

        
      }
  })
      return true;
  }
  return false;

  })
}) 
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>