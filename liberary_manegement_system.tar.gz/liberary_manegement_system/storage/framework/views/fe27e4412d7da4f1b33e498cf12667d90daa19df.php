<?php $__env->startSection('content'); ?>

<div class="container">


<a href="" class="btn btn-primary" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Add Branches </a>

  <table class ="table table-striped table-responsive">
     <thead>

       <tr>
            <th> Id </th>
            <th> Branch Name</th>
          
            <th colsapn = 2> Action </th>
       </tr>
     </thead>
<?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
     
        <tr>
            <td><?php echo e($branch->id); ?></td>
            <td><?php echo e($branch->branch_name); ?></td>
         

     <!-- code to edit/delete button  -->

            <td>
                <a href="#" data-id="<?php echo e($branch->id); ?>" class="btn btn-success edit_branch">Edit</a>
            <td>
    
            <td>
                <button class="btn btn-danger delete_record" data-id="<?php echo e($branch->id); ?>"> Delete </button>
            <td>
        </tr>
                           
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </tbody>
  </table>
</div>

<!--Start Add/edit Modal form -->
<?php echo $__env->make('branches.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('branches.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- code for ajax on delete button -->

<script type="text/javascript">
$(document).ready(function(){
$('.delete_record').click(function(e){
var choice = confirm('Do you really want to delete this record?');
  if(choice === true) {
    e.preventDefault();
  var cutomrurl ="<?php echo e(URL::to('branches/deleteBranch')); ?>";
  $this = $(this)
  var id = $this.data('id');
  $.ajax({
      url:cutomrurl+'/'+id,
      type:'GET',
      dataType: "JSON",
      success:function(response){
        //  console.log(response);
        if(response.status == true) {
          $this.parent().parent('tr').remove();
        }

        
      }
  })
      return true;
  }
  return false;    
})
}) 

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>