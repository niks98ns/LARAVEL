<?php $__env->startSection('content'); ?>
<div class="container">

<form action="<?php echo e(Route('branches.edit')); ?>">

<?php echo e(csrf_field()); ?>

<div class="form-group">
    <input type="hidden" class="form-control" name=_method value="PUT">
</div>
 
 <div class="form-group">
 <label for="branch_name">Branch Name </label>
 <input type="text" class="form-group" name="branch_name" value="<?php echo e($branch->branch_name); ?>">
 </div>

 <div class="form-group">
 <label for="semester">Semester </label>
 <input type="text" class="form-group" name="semester" value="<?php echo e($branch->semester); ?>">
 </div>

        <div>
        <button type="submit" class="btn btn-primary">save </button>
        </div>
</form>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>