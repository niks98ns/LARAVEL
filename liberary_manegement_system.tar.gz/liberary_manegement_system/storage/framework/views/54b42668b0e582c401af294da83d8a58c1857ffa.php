<nav class ="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="collapse navbar-colapse">
        <a href="/" class="navbar-brand">
        <img src="" alt="" class="">
        </a>
    <div>
    </div class="navbar-nav">
    <a href="/" class="nav-item nav-link"> home </a>
    <a href="/" class="nav-item nav-link"> books </a>
    <a href="/" class="nav-item nav-link"> departments </a>
    </div>
</nav>