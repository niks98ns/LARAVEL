<?php $__env->startSection('content'); ?>

<div class="container">

    <a href="<?php echo e(Route('students.create')); ?>" class="btn btn-success">Add students </a>

    <br/>

    <table class ="table table-striped">

      <thead>
        <tr>
        <th>Full Name</th>
        <th>Class Roll Number</th>
        <th>Id number</th>
        <th>Address</th>
        <th>Branch</th>
        <th>email</th>
        </tr>
      </thead>

    
   </div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>