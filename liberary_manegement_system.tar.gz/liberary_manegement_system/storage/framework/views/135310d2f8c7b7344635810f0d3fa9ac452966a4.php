<?php $__env->startSection('content'); ?>

<div class="container">

<a href="<?php echo e(route('student.create')); ?>" class="btn btn-success"> add new student </a>
this index page
</div>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>