<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-10">

        <form action="<?php echo e(Route('students.store')); ?>" method="post">

<?php echo e(csrf_field()); ?>


            <div class="form-group">
            <label for="full_name"> Full Name</label>
            <input type="text" class="form-control" name="full_name">
            </div>

            
            <div class="form-group">
            <label for="branch">Branch</label>
            <input type="text" class="form-control" name="branch">
            </div>


            <div class="form-group">
            <label for="semster"> Semster </label>
            <input type="text" class="form-control" name="semster">
            </div>

            <div class="form-group">
            <label for="address"> Address </label>
            <input type="text" class="form-control" name="address">
            </div>

            <div class="form-group">
            <label for="card_number"> Card Number </label>
            <input type="text" class="form-control" name="card_number">
            </div>

            <div class="form-group">
            <label for="phone_number">Phone Number</label>
            <input type="number" class="form-control" name="phone_number">
            </div>


            <div class="form-group">
            <label for="email">Email</label>
            <input type="text" class="form-control" name="email">
            </div>

            <div>
            <button type="submit" class="btn btn-primary-outline"> student Added </button>
            </div>

            <br/>

            


            
        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>