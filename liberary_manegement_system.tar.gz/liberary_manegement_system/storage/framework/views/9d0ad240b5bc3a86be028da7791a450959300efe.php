<?php $__env->startSection('content'); ?>
<div class= "container">

 <!-- Button trigger modal -->

 <a href="" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Add books </a>

 <table class ="table table-striped table-responsive">

    <thead>
     <tr>
        <th> Id </th>
        <th>BOOK NAME</th>
        <th>AUTHER NAME</th>
        <th>DESCRIPTION</th>
        <th colsapn = 2><center>Action </center> </th> 
    </tr>
    </thead>

    <tbody>
<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($book->id); ?></td>
    <td><?php echo e($book->book_name); ?></td>
    <td><?php echo e($book->auther_name); ?></td>
    <td><?php echo e($book->description); ?></td>


    <!-- code for edit button for update the data in the database-->
                    <td>
                        <a href="#" data-id="<?php echo e($book->id); ?>" class="btn btn-success edit_book">Edit</a>
                        
                    </td>

    <!-- code for delete button for delete the data in the database -->
                    <td>
                            <!-- <form action ="<?php echo e(route('books.destroy',$book->id)); ?>" method="post">
                                <input type ="hidden" name="_method" value="DELETE"> -->
                                <button class="btn btn-danger delete_record" data-id="<?php echo e($book->id); ?>"> Delete </button>
                                <!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
                    <td>
                             </form>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<!--Start Add  Modal -->

<?php echo $__env->make('books.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- End Add modal -->

<!--Start Edit  Modal -->

  <?php echo $__env->make('books.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- end of edit modal -->

<script type="text/javascript">

$(document).ready(function(){
$('.delete_record').click(function(e){
  var choice = confirm('Do you really want to delete this record?');
    if(choice === true) {
      e.preventDefault();
    var cutomrurl ="<?php echo e(URL::to('books/deleteBook')); ?>";
    $this = $(this)
    var id = $this.data('id');
   $.ajax({
        url:cutomrurl+'/'+id,
        type:'GET',
        dataType: "JSON",
        success:function(response){
          // console.log(response);
          if(response.status == true) {
            $this.parent().parent('tr').remove();
          }

         
        }
    })
        return true;
    }
    return false;
// alert()
  //   e.preventDefault();
  //   var cutomrurl ="<?php echo e(URL::to('books/deleteBook')); ?>";
  //   $this = $(this)
  //   var id = $this.data('id');
  //  $.ajax({
  //       url:cutomrurl+'/'+id,
  //       type:'GET',
  //       dataType: "JSON",
  //       success:function(response){
  //         // console.log(response);
  //         if(response.status == true) {
  //           $this.parent().parent('tr').remove();
  //         }

         
  //       }
  //   })  
    
})
}) 


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>