

@extends('layouts.app')
@section('content')
<div class="col-md-12">
    
    {{-- <h2>Home Work List</h2> --}}
    
        {{-- @php
            $_GET['student_class_id'] = ''; 
        @endphp --}}
    
        <a href="{{ url('teachers/create/' . $teacher->id)}}" class="btn btn-success" role="button">Teacher Detail</a>
     
    
        <thead>
            
          
           
            <div class="row">
                   <div class="col-sm-6"><strong>#</strong></div>
                        <td>{{ $teacher->id }}</td><br>
                    <div class="col-sm-6"><strong>First Name</strong></div>
                        <td>{{ $teacher->first_name}}</td><br>
                   <div class="col-sm-6"><strong>Last Name</strong></div>
                        <td>{{ $teacher->last_name }}</td>
                    <div class="col-sm-6"><strong>Email</strong></div><br>
                        <td>{{ $teacher->email }}</td><br>
                    <div class="col-sm-6"><strong>Age</strong></div>
                        <td>{{ $teacher->age}}</td><br>
                   <div class="col-sm-6"><strong>Experience</strong></div>
                        <td>{{ $teacher->experience }}</td><br>
                    <div class="col-sm-6"><strong>Aadhar Id</strong></div>
                        <td>{{ $teacher->aadhar_id }}</td><br>
                    <div class="col-sm-6"><strong>DOB</strong></div>
                        <td>{{ $teacher->dob}}</td><br>
                   <div class="col-sm-6"><strong>Gender</strong></div>
                        <td>{{ $teacher->gender }}</td>
                    <div class="col-sm-6"><strong>Address</strong></div><br>
                        <td>{{ $teacher->address }}</td>
                  
                    
            </div>
        </thead>
        
                                                                                                                                 
          
    </table>
</div>
@endsection




                <table class="table table-striped">
                    <tbody>
                        <tr class="text-center">
                   <div class="col-sm-6"><strong>#</strong></div>
                        <td>{{ $student->id }}</td><br>

                    <div class="col-sm-6"><strong>First Name</strong></div>
                        <td>{{ $student->first_name }}</td><br>

                   <div class="col-sm-6"><strong>Last Name</strong></div>
                        <td>{{ $student->last_name }}</td>

                    <div class="col-sm-6"><strong>Class</strong></div>
                        <td>{{ $student->student_class->class }}
                        {{ $student->student_class->section }}</td>

                    <div class="col-sm-6"><strong>Email</strong></div><br>
                        <td>{{ $student->email }}</td><br>

                    <div class="col-sm-6"><strong>Father Name</strong></div>
                        <td>{{ $student->father_name }}</td><br>

                   <div class="col-sm-6"><strong>Father Name<</strong></div>
                        <td>{{ $student->mother_name }}</td><br>

                    <div class="col-sm-6"><strong>Aadhar ID</strong></div>
                        <td>{{ $student->aadhar_id }}</td><br>

                     <div class="col-sm-6"><strong>AGE</strong></div>
                    <td>{{ $student->age }}</td>

                   <div class="col-sm-6"><strong>DOB</strong></div>
                        <td>{{ $student->dob }}</td>

                    <div class="col-sm-6"><strong>DOA</strong></div><br>
                        <td>{{ $student->doa }}</td> 

                    <div class="col-sm-6"><strong>Image</strong></div><br>
                        <td><img class="rounded" src='{{asset('storage/'.$student->image)}}' height="50px" width="100px"></td> 

                    <div class="col-sm-6"><strong>Gender</strong></div><br>
                    <td>{{ $student->gender }}</td>

                    <div class="col-sm-6"><strong>Address</strong></div><br>
                        <td>{{ $student->address }}</td>
                         
                    <div class="col-sm-6"><strong>City</strong></div><br>
                        <td>{{ $student->city }}</td> 

                    <div class="col-sm-6"><strong>State</strong></div><br>
                    <td>{{ $student->state->name }}</td>

                    <div class="col-sm-6"><strong>Countary</strong></div><br>
                    <td>{{ $student->countary->name }}</td>
                </tr>
                </tbody>
                </table>
