<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Create Session</h2>
    <form class="form-horizontal" id="school_sessions"  method="POST" action="<?php echo e(route('school_sessions.store')); ?>"  novalidate>
        <?php echo e(csrf_field()); ?>


  
        <div class="form-group<?php echo e($errors->has('session_year') ? ' has-error' : ''); ?>">
                <label for="session_year" class="col-md-4 control-label">Session Year</label>
    
                <div class="col-md-6">
                    <input id="year" type="text" class="form-control" name="session_year" value="<?php echo e(old('year')); ?>" required autofocus>
    
                    <?php if($errors->has('session_year')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('session_year')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>