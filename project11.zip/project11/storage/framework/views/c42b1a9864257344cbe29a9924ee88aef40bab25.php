<?php $__env->startSection('content'); ?>
<div class="col-md-12" >
        <h2>Student  List</h2>

        
    
        <a href="<?php echo e(route('students.create', ['student_class_id' => $_GET['student_class_id']])); ?>" class="btn btn-success" role="button">Add Student</a>
     
<table class="table table-striped">
    <thead>
      <tr>
          <th scope="col">#</th>
          <th scope="col">First Name</th>
          <th scope="col">Last Name</th>
          <th scope="col">Email</th>
          
          
          <th>Student Class</th>
          
      </tr>
    </thead>
    <tbody>
       
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        
    <?php
    
    $currentClass = $studentClass = $student->studentClassstudents;
    if ($student->studentClassstudents()->exists()) { 
        $studentClass = $student->studentClassstudents()->get()->last()->studentClass;
        $currentClass = $studentClass['title'] ." ". $studentClass['section'];
        
    }
    ?>
        <tr>
            <td><a href="<?php echo e(route('works.index', $student->id)); ?>" ><?php echo e($student->id); ?></a></td>
            <td><?php echo e($student->first_name); ?></td>
            <td><?php echo e($student->last_name); ?></td>
            <td><?php echo e($student->email); ?></td>
            
            
                  
                

        
                <td><?php echo e($currentClass); ?></td>
                
                
            <td>
            
                <input type="hidden" data_id="student_id" name="student_id" value="<?php echo e($student->id); ?>">
                <button type="button" id="<?php echo e($student->id); ?>" class="btn btn-info btn-lg btn_show" data-toggle="modal" data-target="#showdetail">Student Detail</button>
                
                

                <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-default">
                    Edit
                </a>

                <form class="form-horizontal pull-right" action="<?php echo e(URL::route('students.destroy', ['id' => $student->id, 'student_class_id' => $_GET['student_class_id']])); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE"/>
                    <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                        Delete
                    </button>
                    
                </form>

            </td>
        
        </tr>   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<!-- Modal -->
<div id="modalViewDetails" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title table table-stripped"><strong>Student List</strong></h4>
        </div>
        <div class="modal-body table table-stripped"></div>





        <input type="hidden" data_id="student_id" name="student_id" value="<?php echo e($student->id); ?>">
        <td> <select id=<?php echo e($student->id); ?> class="btn_show" name="student" id="student-id" >
            
                
                    
                        <option value="">--------Selected--------</option >
                        <option value="0" <?php if($student->status==0): ?> selected <?php endif; ?>>Active</option>
                        <option value="1" <?php if($student->status==1): ?> selected <?php endif; ?>>In Active</option>        
                    </select>
            
            
        </td>
        



        

        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="jquery-3.4.1.min.js"></script>
<script src="<?php echo e(asset('js/ajax.js')); ?>"></script>
<script src="ajax.js"></script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>