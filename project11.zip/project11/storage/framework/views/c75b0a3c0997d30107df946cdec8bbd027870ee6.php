<?php $__env->startSection('content'); ?>

<div class="col-md-12">
        <h2>Edit Feedback</h2>
        
        <form class="form-horizontal" id="feedbacks" action="<?php echo e(URL::route('feedbacks.update', [$feedback->id])); ?>" method="POST" novalidate>
   
        <?php echo e(csrf_field()); ?>

       
        <input type="hidden" name="_method" value="PUT"/>
     
        <div class="form-group<?php echo e($errors->has('month') ? ' has-error' : ''); ?>">
                <label for="month" class="col-md-4 control-label">Month</label>
    
                <div class="col-md-6">
                    <select name="month">
                        <option value="">----select----</option>
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>
                
                    
                    <?php if($errors->has('month')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('month')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                <label for="description" class="col-md-4 control-label">Description</label>
    
                <div class="col-md-6">
                    <input id="description" type="text" class="form-control" name="description" value="<?php echo e($feedback->description); ?>" required autofocus>
    
                    <?php if($errors->has('description')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('student_id') ? ' has-error' : ''); ?>">
            <label for="student_id" class="col-md-4 control-label"></label>

            <div class="col-md-6">
                <input id="student_id" type="hidden" class="form-control" name="student_id" value="<?php echo e($feedback->id); ?>">

                <?php if($errors->has('student_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('student_id')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

       <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>