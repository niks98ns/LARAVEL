<?php $__env->startSection('content'); ?>


<div class="col-md-12">
        <h2>School List</h2>
        
        <a href="<?php echo e(route('schools.create')); ?>" class="btn btn-success" role="button">Add School</a>
<table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Title</th>
        <th scope="col">Date Of Opening</th>
        <th scope="col">Address</th>
        <th scope="col">City</th>
        <th scope="col">State ID</th>
        <th scope="col">Countary ID</th>
      </tr>
    </thead>
    <tbody>
          
     <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($school->id); ?></td>
            <td><?php echo e($school->name); ?></td>
            <td><?php echo e($school->title); ?></td>
            <td><?php echo e($school->ddate_of_openingob); ?></td>
            <td><?php echo e($school->address); ?></td>
            <td><?php echo e($school->city); ?></td>
            <td><?php echo e($school->state_id); ?></td>
            <td><?php echo e($school->countary_id); ?></td>
            <td>
                <a href="<?php echo e(route('schools.edit', $school->id)); ?>" class="btn btn-default">
                    Edit
                </a>

                <form class="form-horizontal pull-right" action="<?php echo e(URL::route('schools.destroy', [$school->id])); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE"/>
                    <button type="submit" class="btn btn-danger">
                        Delete
                    </button>
                </form>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>