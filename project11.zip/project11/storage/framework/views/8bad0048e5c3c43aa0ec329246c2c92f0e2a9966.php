<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    
    <h2>Home Work List</h2>
    
    <?php
        $_GET['student_class_id'] = ''; 
    ?>
        
    
    <a href="<?php echo e(route('works.create', ['student_class_id' => $_GET['student_class_id']])); ?>" class="btn btn-success" role="button">Home Work</a>

          
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Date</th>
                                       
            </tr>
           
        </thead>
        
        <tbody> 
            
              
                
                        
                <?php $__currentLoopData = $works->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($work->id); ?></td>
                    <td><?php echo e($work->title); ?></td>
                    <td><?php echo e($work->description); ?></td>
                    <td><?php echo e($work->created_at); ?></td>
                 
                 
                    <td>
                        
                        
                         

                        
                        
                        

                

                
                    </td>
                                                                   
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>