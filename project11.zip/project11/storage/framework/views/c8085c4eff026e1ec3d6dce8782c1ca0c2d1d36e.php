<?php $__env->startSection('content'); ?>

<div class="col-md-12" >
        <h2>Teacher  List</h2>
    
        <?php
        $_GET['student_class_id'] = ''; 
    ?>
   
        <a href="<?php echo e(route('teachers.create', ['student_class_id' => $_GET['student_class_id']])); ?>" class="btn btn-success" role="button">Add Teacher</a> 
       
        
<table class="table table-striped">
    <thead>
      <tr>
          <th scope="col">#</th>
          
          <th scope="col">First Name</th>
          <th scope="col">Last Name</th>
          <th scope="col">Student Class</th>
          <th scope="col">Email</th>
          <th scope="col">Age</th>
          <th scope="col">Experience</th>
          <th scope="col">Aadhar ID</th>
          <th scope="col">DOB</th>
          <th scope="col">Gender</th>
          <th scope="col">Address</th>
      </tr>
    </thead>
    <tbody>
       
    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td><?php echo e($teacher->id); ?></td>
            <td><a href="<?php echo e(route('teachers.show', $teacher->id)); ?>" ><?php echo e($teacher->first_name); ?></a></td>
            <td><?php echo e($teacher->last_name); ?></td>
            
            
            <td>
                <?php $__currentLoopData = $teacher->StudentClass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $StudentClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($StudentClass->title); ?><?php echo e($StudentClass->section); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </td>
            <td><?php echo e($teacher->email); ?></td>
            <td><?php echo e($teacher->age); ?></td>
            <td><?php echo e($teacher->experience); ?></td>
            <td><?php echo e($teacher->aadhar_id); ?></td>
            <td><?php echo e($teacher->dob); ?></td>
            <td><?php echo e($teacher->gender); ?></td>
            <td><?php echo e($teacher->address); ?></td>

            
            <td>
                <a href="<?php echo e(route('teachers.edit', $teacher->id)); ?>" class="btn btn-default">
                    Edit
                </a>

                <form class="form-horizontal pull-right" action="<?php echo e(URL::route          ('teachers.destroy', ['id' => $teacher->id, 'student_class_id' => $_GET['student_class_id']])); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE"/>
                    <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                        Delete
                    </button>
                    
                </form>

              
 
            </td>
        
        </tr>   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>