<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    
    
    
        
    
        <a href="<?php echo e(url('teachers/create/' . $teacher->id)); ?>" class="btn btn-success" role="button">Teacher Detail</a>
     
    
        <thead>
            
          
           
            <div class="row">
                   <div class="col-sm-6"><strong>#</strong></div>
                        <td><?php echo e($teacher->id); ?></td><br>
                    <div class="col-sm-6"><strong>First Name</strong></div>
                        <td><?php echo e($teacher->first_name); ?></td><br>
                   <div class="col-sm-6"><strong>Last Name</strong></div>
                        <td><?php echo e($teacher->last_name); ?></td>
                    <div class="col-sm-6"><strong>Email</strong></div><br>
                        <td><?php echo e($teacher->email); ?></td><br>
                    <div class="col-sm-6"><strong>Age</strong></div>
                        <td><?php echo e($teacher->age); ?></td><br>
                   <div class="col-sm-6"><strong>Experience</strong></div>
                        <td><?php echo e($teacher->experience); ?></td><br>
                    <div class="col-sm-6"><strong>Aadhar Id</strong></div>
                        <td><?php echo e($teacher->aadhar_id); ?></td><br>
                    <div class="col-sm-6"><strong>DOB</strong></div>
                        <td><?php echo e($teacher->dob); ?></td><br>
                   <div class="col-sm-6"><strong>Gender</strong></div>
                        <td><?php echo e($teacher->gender); ?></td>
                    <div class="col-sm-6"><strong>Address</strong></div><br>
                        <td><?php echo e($teacher->address); ?></td>
                  
                    
            </div>
        </thead>
        
                                                                                                                                 
          
    </table>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>