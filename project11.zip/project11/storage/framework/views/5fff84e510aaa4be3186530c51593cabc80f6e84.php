<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    
    <h2>Home Work List</h2>
    
    <?php
        $_GET['student_class_id'] = ''; 
    ?>
        
    <a href="<?php echo e(route('works.create', ['student_class_id' => $_GET['student_class_id']])); ?>" class="btn btn-success" role="button">Home Work</a><br><br>
   

          <div class="row">
                <div class="col-sm-12"><strong>Student Class:</strong> <?php echo e($student_class->title); ?>(<?php echo e($student_class->section); ?>)</div>
                
          </div>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Date</th>
                                       
            </tr>
           
        </thead>
        
        <tbody>                                                                                                                         
             
            <?php $__currentLoopData = $student_class->works()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
                <tr>
                    <td><?php echo e($work->id); ?></td>
                    <td><a href="<?php echo e(route('works.show', $student_class->id)); ?>" ><?php echo e($work->title); ?></a></td>
                    <td><?php echo e($work->description); ?></td>
                    <td><?php echo e($work->created_at); ?></td>
            
                    <td>
                        
                        <a href="<?php echo e(url ('student_classes.editWorks', $student_class->id)); ?>" class="btn btn-default">
                            Edit
                        </a>
                        
                        <?php
                        $_GET['work_id'] = ''; 
                    ?>
                    
                        
                
                <form class="form-horizontal pull-right" action="<?php echo e(URL::route('student_classes.destroy', [$student_class->id])); ?>" method="POST" >
                    <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="DELETE"/>
                <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                    Delete
                </button>
            </form>
                    </td>
                                                                   
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>