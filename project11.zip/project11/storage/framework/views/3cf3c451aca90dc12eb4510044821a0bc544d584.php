<?php $__env->startSection('content'); ?>
<div class="col-md-12" >
        <h2>Student  List</h2>
    
           
        
<table class="table table-striped">
    <thead>
      <tr>
          <th scope="col">#</th>
          <th scope="col">First Name</th>
          <th scope="col">Last Name</th>
          <th scope="col">Email</th>
          <th scope="col">Father Name</th>
          <th scope="col">Mother Name</th>
          <th scope="col">Aadhar ID</th>
          <th scope="col">DOB</th>
          <th scope="col">DOA </th>
          <th scope="col">Photo</th>
          <th scope="col">Gender</th>
          <th scope="col">Address</th>
          <th scope="col">Teacher Name</th>
          <th scope="col">Student Class</th>
          <th scope="col">City</th>
          <th scope="col">State ID</th>
          <th scope="col">Countary ID</th>
      </tr>
    </thead>
    <tbody>
   
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        
    <?php
    
    $currentClass = $studentClass = $student->studentClassstudents;
    if ($student->studentClassstudents()->exists()) { 
        $studentClass = $student->studentClassstudents()->get()->last()->studentClass;
        $currentClass = $studentClass['title'] ." ". $studentClass['section'];
        
    }
    ?>
        <tr>
            <td><a href="<?php echo e(route('works.index', $student->id)); ?>" ><?php echo e($student->id); ?></a></td>
            <td><?php echo e($student->first_name); ?></td>
            <td><?php echo e($student->last_name); ?></td>
            <td><?php echo e($student->email); ?></td>
            <td><?php echo e($student->father_name); ?></td>
            <td><?php echo e($student->mother_name); ?></td>
            <td><?php echo e($student->aadhar_id); ?></td>
            <td><?php echo e($student->dob); ?></td>
            <td><?php echo e($student->doa); ?></td>
            <td><?php echo e($student->photo); ?></td>
            <td><?php echo e($student->gender); ?></td>
            <td><?php echo e($student->address); ?></td>
            <td><?php echo e($student->studentClass->teacher->first_name); ?>

                <?php echo e($student->studentClass->teacher->last_name); ?></td>
                  
                
                <td><?php echo e($currentClass); ?></td>
                <td><?php echo e($student->city); ?></td>
                <td><?php echo e($student->state->name); ?></td>
                <td><?php echo e($student->countary->name); ?></td>
            
        </tr>   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('js/ajax.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>