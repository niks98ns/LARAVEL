<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Assign Class</h2>
    <form class="form-horizontal" id="teachers"  method="POST" action="<?php echo e(url('student_fees/storestudentfees')); ?>"  novalidate>
        <?php echo e(csrf_field()); ?>


        <div class="form-group<?php echo e($errors->has('student_class') ? ' has-error' : ''); ?>">
                <label for="student_class" class="col-md-4 control-label">Student Class </label>
    
                <div class="col-md-6">
                 
                    <select name="student_class_id">
                            
                        <option value="">----Select-----</option>
                        <?php $__currentLoopData = $student_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <option value="<?php echo e($student_class->id); ?>"><?php echo e($student_class->title); ?> <?php echo e($student_class->section); ?></option>
                             
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </select>

                    <?php if($errors->has('student_class')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('student_class')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

           <div class="form-group"> 
            <input type="hidden"  name="student_fee_id" value="<?php echo e($student_fee_id); ?>">        
        </div>

        
       

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>