<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Create Class</h2>
    <form class="form-horizontal"  id="school" method="POST" action="<?php echo e(route('schools.store')); ?>" novalidate>
        <?php echo e(csrf_field()); ?>


         <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-4 control-label">Name</label>
    
                <div class="col-md-6">
                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
    
                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                <label for="title" class="col-md-4 control-label">Title</label>
    
                <div class="col-md-6">
                    <input id="title" type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" required autofocus>
    
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        

        <div class="form-group<?php echo e($errors->has('date_of_opening') ? ' has-error' : ''); ?>">
                <label for="date_of_opening" class="col-md-4 control-label">Date Of Opening</label>
    
                <div class="col-md-6">
                    <input id="date_of_opening" type="date" class="form-control" name="date_of_opening" value="<?php echo e(old('date_of_opening')); ?>"  required autofocus>
    
                    <?php if($errors->has('date_of_opening')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('date_of_opening')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>


        <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
            <label for="address" class="col-md-4 control-label">Address</label>

            <div class="col-md-6">
                <input id="address" type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" required autofocus>

                <?php if($errors->has('address')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('address')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

    <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
            <label for="city" class="col-md-4 control-label">City</label>

            <div class="col-md-6">
                <input id="city" type="text" class="form-control" name="city" value="<?php echo e(old('city')); ?>" required autofocus>

                <?php if($errors->has('city')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('city')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

    <div class="form-group<?php echo e($errors->has('state_id') ? ' has-error' : ''); ?>">
            <label for="state_id" class="col-md-4 control-label">State</label>

            <div class="col-md-6">
                    <select name="state_id">
                            <option value="">----Select-----</option>
                            <option value="1" >Haryana</option>
                            <option value="2">Assam</option>
                            <option value="3">GOA</option>
                            <option value="4">Himachal Pradesh</option>
                            <option value="5">Jammu & Kashmir</option>
                            <option value="6">Maharashtra</option>
                           
                          </select>
                          

                <?php if($errors->has('state_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('state_id')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

    <div class="form-group<?php echo e($errors->has('countary_id') ? ' has-error' : ''); ?>">
            <label for="countary_id" class="col-md-4 control-label">Countary</label>

            <div class="col-md-6">
                    <select name="countary_id">
                            <option value="">-----Select-----</option>
                            <option value="1">USA</option>
                            <option value="2">UAE</option>
                            <option value="3">India</option>
                            <option value="4">Australia</option>
                            <option value="5">New zeeland'</option>
                            <option value="6">Japan</option>
                           
                    </select>
                       
                        

                <?php if($errors->has('countary_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('countary_id')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

    

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>