<?php $__env->startSection('content'); ?>


<div class="col-md-12">
        <h2>List Class Fees</h2> 
       <!--  
        <a href="<?php echo e(route('student_fees.create', ['student_class_id' => $_GET['student_class_id']])); ?>" class="btn btn-success" role="button">Create Class</a> 
 
        
<table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Student Fees</th>
        <th scope="col">Student Class</th>
  
      </tr>
    </thead>
  <tbody> 
     <?php $__currentLoopData = $student_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
        <tr>
                
            
            <table></table>d><?php echo e($student_fee->id); ?></td>
            <td><a href="<?php echo e(route('student_fees.show', $student_fee->id)); ?>" ><?php echo e($student_fee->class_fees); ?></a></td>
            <td><?php echo e($student_fee->studentClass->title); ?>

                    <?php echo e($student_fee->studentClass->section); ?></td>
            
          
            <td>
                <a href="<?php echo e(route('student_fees.edit', $student_fee->id)); ?>" class="btn btn-default">
                    Edit
                </a>
             

                <form class="form-horizontal pull-right" action="<?php echo e(URL::route('student_fees.destroy', ['id' => $student_fee->id, 'student_class_id' => $_GET['student_class_id']])); ?>" method="POST" >
                  <?php echo e(csrf_field()); ?>

              <input type="hidden" name="_method" value="DELETE"/>
              <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">Delete</button>
          </form>

            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>