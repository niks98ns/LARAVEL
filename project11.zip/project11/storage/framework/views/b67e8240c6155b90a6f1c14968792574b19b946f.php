<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    
    
    
        <a href="<?php echo e(url('student_fees/create/' . $student_fee->id)); ?>" class="btn btn-success" role="button">Student Fees Detail</a>
     
        <thead>
     
            <div class="row">
                   <div class="col-sm-6"><strong>#</strong></div>
                        <td><?php echo e($student_fee->id); ?></td><br>
                    <div class="col-sm-6"><strong>Class Fee</strong></div>
                        <td><?php echo e($student_fee->class_fees); ?></td><br>
                 
                 
            </div>
        </thead>
     
    </table>
</div>
<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>