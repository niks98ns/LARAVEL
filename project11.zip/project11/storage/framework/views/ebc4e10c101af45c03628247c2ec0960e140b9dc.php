<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Create Class</h2>
    <form class="form-horizontal"  id="students" method="POST" action="<?php echo e(route('students.store')); ?>" enctype="multipart/form-data" novalidate>
        <?php echo e(csrf_field()); ?>


         <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                <label for="first_name" class="col-md-4 control-label">First Name</label>
    
                <div class="col-md-6">
                    <input id="first_name" type="text" class="form-control" name="first_name" value="<?php echo e(old('first_name')); ?>" required autofocus>
    
                    <?php if($errors->has('first_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('first_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                <label for="last_name" class="col-md-4 control-label">Last Name</label>
    
                <div class="col-md-6">
                    <input id="last_name" type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>" required autofocus>
    
                    <?php if($errors->has('last_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('last_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email" class="col-md-4 control-label">Email</label>
    
                <div class="col-md-6">
                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
    
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('father_name') ? ' has-error' : ''); ?>">
                <label for="father_name" class="col-md-4 control-label">Father Name</label>
    
                <div class="col-md-6">
                    <input id="father_name" type="text" class="form-control" name="father_name" value="<?php echo e(old('father_name')); ?>" required autofocus>
    
                    <?php if($errors->has('father_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('father_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('mother_name') ? ' has-error' : ''); ?>">
                <label for="mother_name" class="col-md-4 control-label">Mother Name</label>
    
                <div class="col-md-6">
                    <input id="mother_name" type="text" class="form-control" name="mother_name" value="<?php echo e(old('mother_name')); ?>" required autofocus>
    
                    <?php if($errors->has('mother_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('mother_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('aadhar_id') ? ' has-error' : ''); ?>">
                <label for="aadhar_id" class="col-md-4 control-label">Aadhar ID</label>
    
                <div class="col-md-6">
                    <input id="aadhar_id" type="number" class="form-control" name="aadhar_id" value="<?php echo e(old('aadhar_id')); ?>" required autofocus>
    
                    <?php if($errors->has('aadhar_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('aadhar_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('dob') ? ' has-error' : ''); ?>">
                <label for="dob" class="col-md-4 control-label">DOB</label>
    
                <div class="col-md-6">
                    <input id="dob" type="date" class="form-control" name="dob" value="<?php echo e(old('dob')); ?>"  required autofocus>
    
                    <?php if($errors->has('dob')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('dob')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('doa') ? ' has-error' : ''); ?>">
                <label for="doa" class="col-md-4 control-label">DOA</label>
    
                <div class="col-md-6">
                    <input id="doa" type="date" class="form-control" name="doa" value="<?php echo e(old('doa')); ?>" required autofocus>
    
                    <?php if($errors->has('doa')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('doa')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('photo') ? ' has-error' : ''); ?>">
                <label for="photo" class="col-md-4 control-label">Photo</label>
    
                <div class="col-md-6">
                    <input id="photo" type="file" class="form-control" name="photo" value="<?php echo e(old('photo')); ?>"/>
                            
                    <?php if($errors->has('photo')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('photo')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                <label for="gender" class="col-md-4 control-label">Gender</label>
    
                <div class="col-md-6">
                    <input id="gender" type="radio" name="gender" value="male" Checked>Male
                    <input id="gender" type="radio" name="gender" value="female">Female
    
                    <?php if($errors->has('gender')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('gender')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                <label for="address" class="col-md-4 control-label">Address</label>
    
                <div class="col-md-6">
                    <input id="address" type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" required autofocus>
    
                    <?php if($errors->has('address')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('address')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                <label for="city" class="col-md-4 control-label">City</label>
    
                <div class="col-md-6">
                    <input id="city" type="text" class="form-control" name="city" value="<?php echo e(old('city')); ?>" required autofocus>
    
                    <?php if($errors->has('city')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('city')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('state_id') ? ' has-error' : ''); ?>">
                <label for="state_id" class="col-md-4 control-label">State</label>
    
                <div class="col-md-6" >
                       
                        <select name="state_id" >
                            <option value="">----Select-----</option>
                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </select>
     
                    <?php if($errors->has('state_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('state_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('countary_id') ? ' has-error' : ''); ?>">
                <label for="countary_id" class="col-md-4 control-label">Countary</label>
    
                <div class="col-md-6">
                       
                        <select name="countary_id" >
                            <option value="">----Select-----</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                    <?php if($errors->has('countary_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('countary_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
            <label for="status" class="col-md-4 control-label">Status</label>

            <div class="col-md-6" id=$student>
                   
                <select name="status">
                    <option value="0">Active</option>
                    <option value="1">IN Active</option>
                </select>
                    
                <?php if($errors->has('status')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('status')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

         

        <div class="form-group"> 
            <input id="student_class_id" type="hidden"  name="student_class_id" value="<?php echo e($_GET['student_class_id']); ?>">        
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>