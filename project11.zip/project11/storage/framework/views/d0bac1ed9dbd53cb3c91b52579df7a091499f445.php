<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Create Guardian</h2>
    <form class="form-horizontal"  id="form" method="POST" action="<?php echo e(route('guardians.store')); ?>" enctype="multipart/form-data" novalidate>
        <?php echo e(csrf_field()); ?>


       

         <div class="form-group<?php echo e($errors->has('father_name') ? ' has-error' : ''); ?>">
                <label for="father_name" class="col-md-4 control-label">Father Name</label>
    
                <div class="col-md-6">
                    <input id="father_name" type="text" class="form-control" name="father_name" value="<?php echo e(old('father_name')); ?>" required autofocus>
    
                    <?php if($errors->has('father_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('father_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('father_image') ? ' has-error' : ''); ?>">
                <label for="father_image" class="col-md-4 control-label">Father Image</label>
    
                <div class="col-md-6">
                    <input id="father_image" type="file" class="form-control" name="father_image" value="<?php echo e(old('father_image')); ?>" required autofocus>
    
                    <?php if($errors->has('father_image')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('father_image')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        

        <div class="form-group<?php echo e($errors->has('father_occupation') ? ' has-error' : ''); ?>">
                <label for="father_occupation" class="col-md-4 control-label">Father Occupation</label>
    
                <div class="col-md-6">
                    <input id="father_occupation" type="text" class="form-control" name="father_occupation" value="<?php echo e(old('father_occupation')); ?>"  required autofocus>
    
                    <?php if($errors->has('father_occupation')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('father_occupation')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('mother_name') ? ' has-error' : ''); ?>">
            <label for="mother_name" class="col-md-4 control-label">Mother Name</label>

            <div class="col-md-6">
                <input id="mother_name" type="text" class="form-control" name="mother_name" value="<?php echo e(old('mother_name')); ?>" required autofocus>

                <?php if($errors->has('mother_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('mother_name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

    <div class="form-group<?php echo e($errors->has('mother_image') ? ' has-error' : ''); ?>">
            <label for="mother_image" class="col-md-4 control-label">Mother Image</label>

            <div class="col-md-6">
                <input id="mother_image" type="file" class="form-control" name="mother_image" value="<?php echo e(old('mother_image')); ?>" required autofocus>

                <?php if($errors->has('mother_image')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('mother_image')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

    

    <div class="form-group<?php echo e($errors->has('mother_occupation') ? ' has-error' : ''); ?>">
            <label for="mother_occupation" class="col-md-4 control-label">Mother Occupation</label>

            <div class="col-md-6">
                <input id="mother_occupation" type="text" class="form-control" name="mother_occupation" value="<?php echo e(old('mother_occupation')); ?>"  required autofocus>

                <?php if($errors->has('mother_occupation')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('mother_occupation')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
    </div>

    <div class="form-group"> 
        <input id="student_id" type="hidden"  name="student_id" value="<?php echo e($_GET['student_id']); ?>">        
    </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>