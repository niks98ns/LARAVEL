<?php $__env->startSection('content'); ?>

<div class="col-md-12">
        <h2>Edit Class Fees</h2> 
 
    <form class="form-horizontal" id="student_fees" action="<?php echo e(URL::route('student_fees.update', [$student_fees->id])); ?>" method="POST" novalidate>
        <?php echo e(csrf_field()); ?>

       
        <input type="hidden" name="_method" value="PUT"/>
        <div class="form-group<?php echo e($errors->has('class_fees') ? ' has-error' : ''); ?>">
            <label for="class_fees" class="col-md-4 control-label">Class Fees</label>

            <div class="col-md-6">
                <input id="class_fees" type="text" class="form-control" name="class_fees" value="<?php echo e($student_fees->class_fees); ?>" required autofocus>

                <?php if($errors->has('class_fees')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('class_fees')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('student_class_id') ? ' has-error' : ''); ?>">
                <label for="student_class_id" class="col-md-4 control-label"></label>
    
                <div class="col-md-6">
                    <input id="student_class_id" type="hidden" class="form-control" name="student_class_id" value="<?php echo e($student_fees->id); ?>">
    
                    <?php if($errors->has('student_class_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('student_class_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>