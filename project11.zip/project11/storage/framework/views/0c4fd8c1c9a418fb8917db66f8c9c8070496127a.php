<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>School Session List</h2>
    
    <a href="<?php echo e(route('school_sessions.create')); ?>" class="btn btn-success" role="button">Add Session</a>   
    <table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">#</th>
          <th scope="col">Session Year</th>
        
       
        </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $school_sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($school_session->id); ?></td>
            <td><?php echo e($school_session->session_year); ?></td>
         
            <td>
                <a href="<?php echo e(route('school_sessions.edit', $school_session->id)); ?>" class="btn btn-default">
                    Edit
                </a>

                <form class="form-horizontal pull-right" action="<?php echo e(URL::route('school_sessions.destroy', [$school_session->id])); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE"/>
                    <button type="submit" class="btn btn-danger">
                        Delete
                    </button>
                </form>
               
            
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>