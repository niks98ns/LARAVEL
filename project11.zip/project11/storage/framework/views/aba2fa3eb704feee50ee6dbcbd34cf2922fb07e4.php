<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    
    <h2>Home Work List</h2>
    
        <a href="<?php echo e(url('students/studentDetail/' . $student->id)); ?>" class="btn btn-success" role="button">Student Detail</a>
     
        <thead>
     
            <div class="row">
                <div class="col-sm-6"><strong>#</strong></div>
                     <td><?php echo e($student->id); ?></td><br>
                 <div class="col-sm-6"><strong>First Name</strong></div>
                     <td><?php echo e($student->first_name); ?></td><br>
                <div class="col-sm-6"><strong>Last Name</strong></div>
                     <td><?php echo e($student->last_name); ?></td>
                <div class="col-sm-6"><strong>Email</strong></div><br>
                     <td><?php echo e($student->email); ?></td><br>
                <div class="col-sm-6"><strong>Father Name</strong></div>
                     <td><?php echo e($student->father_name); ?></td><br>
                <div class="col-sm-6"><strong>Mother Name</strong></div>
                     <td><?php echo e($student->mother_name); ?></td><br>
                 <div class="col-sm-6"><strong>Aadhar Id</strong></div>
                     <td><?php echo e($student->aadhar_id); ?></td><br>
                 <div class="col-sm-6"><strong>DOB</strong></div>
                     <td><?php echo e($student->dob); ?></td><br>
                <div class="col-sm-6"><strong>DOA</strong></div>
                     <td><?php echo e($student->doa); ?></td>
                <div class="col-sm-6"><strong>	Photo</strong></div><br>
                     <td><?php echo e($student->photo); ?></td><br>
                <div class="col-sm-6"><strong>Gender</strong></div>
                     <td><?php echo e($student->gender); ?></td><br>
                <div class="col-sm-6"><strong>Address</strong></div>
                     <td><?php echo e($student->address); ?></td><br>
                <div class="col-sm-6"><strong>Teacher Name</strong></div><br>
                     <td><?php echo e($student->teacher_name); ?></td>
                <div class="col-sm-6"><strong>	Student Class</strong></div><br>
                     <td><?php echo e($student->address); ?></td>
                <div class="col-sm-6"><strong>City</strong></div>
                     <td><?php echo e($student->city); ?></td><br>
                <div class="col-sm-6"><strong>State ID</strong></div>
                     <td><?php echo e($student->state_id); ?></td>
                <div class="col-sm-6"><strong>Countary ID</strong></div><br>
                     <td><?php echo e($student->countary_id); ?></td>
                 
         </div>
        </thead>
     
    </table>
</div>
<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>