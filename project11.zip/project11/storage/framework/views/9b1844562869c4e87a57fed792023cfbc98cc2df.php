<?php $__env->startSection('content'); ?>

<div class="col-md-12">
        <h2>Edit Student</h2>
    <form class="form-horizontal" action="<?php echo e(URL::route('student_classes.update', [$student_class->id])); ?>" method="POST" novalidate>
        <?php echo e(csrf_field()); ?>

       
        <input type="hidden" name="_method" value="PUT"/>
        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
            <label for="title" class="col-md-4 control-label">Title</label>

            <div class="col-md-6">
                <input id="title" type="text" class="form-control" name="title" value="<?php echo e($student_class->title); ?>" required autofocus>

                <?php if($errors->has('title')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('title')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('section') ? ' has-error' : ''); ?>">
            <label for="section" class="col-md-4 control-label">Section</label>

            <div class="col-md-6">
                <input id="section" type="text" class="form-control" name="section" value="<?php echo e($student_class->section); ?>" required autofocus>

                <?php if($errors->has('section')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('section')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('work_id') ? ' has-error' : ''); ?>">
            <label for="work_id" class="col-md-4 control-label"></label>

            <div class="col-md-6">
                <input id="work_id" type="hidden" class="form-control" name="work_id" value="<?php echo e($student_class->id); ?>">

                <?php if($errors->has('work_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('work_id')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

       
        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>