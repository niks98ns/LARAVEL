<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Home Work List</h2>
    
    
    
    
    <a href="" class="btn btn-success" role="button">Add Home Work</a> 
    
    <table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">#</th>
          <th scope="col">Title</th>
          <th scope="col">Description</th>
          <th scope="col">Action</th>
            
      
        </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($work->id); ?></td>
            <td><?php echo e($work->title); ?></td>
            <td><?php echo e($work->description); ?></td>
         
         
            <td>
                <a href="<?php echo e(route('works.edit', $work->id)); ?>" class="btn btn-default">
                    Edit
                </a>
                
              
                <form class="form-horizontal pull-right" action="<?php echo e(URL::route('works.destroy', [$work->id])); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE"/>
                    <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                        Delete
                    </button>
                </form>
               
            
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>