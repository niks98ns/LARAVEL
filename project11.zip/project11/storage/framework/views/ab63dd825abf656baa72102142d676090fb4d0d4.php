<?php $__env->startSection('content'); ?>

<div class="col-md-12">
        <h2>Edit Student</h2>
    <form class="form-horizontal"  id="student_class_students" action="<?php echo e(URL::route('student_class_students.update', [$student_class_student->id])); ?>" method="POST" enctype="multipart/form-data" novalidate>
        <?php echo e(csrf_field()); ?>

       
        <input type="hidden" name="_method" value="PUT"/>
        <div class="form-group<?php echo e($errors->has('student_class') ? ' has-error' : ''); ?>">
                <label for="student_class" class="col-md-4 control-label">Student Class</label>
    
                <div class="col-md-6">


                    <select name="student_class" >
                        <option value="">-----Select-----</option>
                        
                        <?php $__currentLoopData = $student_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                             <option value="<?php echo e($student_class->id); ?>" <?php if($student_class->id == $student_class_student->student_class_id): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($student_class->title); ?> <?php echo e($student_class->section); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php if($errors->has('first_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('student_class')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('student_id') ? ' has-error' : ''); ?>">
            <label for="student_id" class="col-md-4 control-label"></label>

            <div class="col-md-6">
                <input id="student_id" type="hidden" class="form-control" name="student_id" value="<?php echo e($student_class_student->id); ?>">

                <?php if($errors->has('student_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('student_id')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('school_session_id') ? ' has-error' : ''); ?>">
                <label for="school_session_id" class="col-md-4 control-label">School Session </label>
    
                <div class="col-md-6">

                        <select name="school_session_id" >
                            
                                <option value="">----Select-----</option>
                                <?php $__currentLoopData = $school_sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <option value="<?php echo e($school_session->id); ?>" <?php if($school_session->id == $student_class_student->school_session_id): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($school_session->session_year); ?> </option>
                                     
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        
                      
                    <?php if($errors->has('school_session_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('school_session_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

       
       <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>