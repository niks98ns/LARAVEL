<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    
    
    
        
    
        
     
    
        <thead>
            
          
           
            <div class="row">
                   <div class="col-sm-6"><strong>#</strong></div>
                        <td><?php echo e($work->id); ?></td><br>
                    <div class="col-sm-6"><strong>Title</strong></div>
                        <td><?php echo e($work->title); ?></td><br>
                   <div class="col-sm-6"><strong>Description</strong></div>
                        <td><?php echo e($work->description); ?></td>
                    <div class="col-sm-6"><strong>Date</strong></div><br>
                        <td><?php echo e($work->created_at); ?></td>
                  
                    
            </div>
        </thead>
        
        <tbody>                                                                                                                         
          
    </table>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>