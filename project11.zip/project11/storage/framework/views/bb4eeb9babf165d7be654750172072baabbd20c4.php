<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Create Class Fee</h2>
    <form class="form-horizontal" id="student_fees" method="POST" action="<?php echo e(route('student_fees.store')); ?>" novalidate>
        <?php echo e(csrf_field()); ?>


        <div class="form-group<?php echo e($errors->has('class_fees') ? ' has-error' : ''); ?>">
            <label for="class_fees" class="col-md-4 control-label">Class Fees</label>
            <div class="col-md-6">
                <input id="class_fees" type="text" class="form-control" name="class_fees" value="<?php echo e(old('class_fees')); ?>">
                <?php if($errors->has('class_fees')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('class_fees')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

       <div class="form-group"> 
            <input id="student_class_id" type="hidden"  name="student_class_id" value="<?php echo e($_GET['student_class_id']); ?>">        
        </div>

    
        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<script src="http://cdnjs/app.user_validation.js/jquery.validate.min.js"></script>
    <script src="http://cdnjs/app.user_validation.js/additional-methods.min.js"></script>
    <script src="http://localhost/project/public/js/user_validation.js"></script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>