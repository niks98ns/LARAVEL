<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Create Home Work</h2>
    <form class="form-horizontal" id="works"  method="POST" action="<?php echo e(route('works.store')); ?>"  novalidate>
        <?php echo e(csrf_field()); ?>


  
        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                <label for="title" class="col-md-4 control-label">Title </label>
    
                <div class="col-md-6">
                    <input id="title" type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" required autofocus>
    
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
        </div>

        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
            <label for="description" class="col-md-4 control-label">Description</label>

            <div class="col-md-6">
                <input id="description" type="text" class="form-control" name="description" value="<?php echo e(old('description')); ?>" required autofocus>

                <?php if($errors->has('description')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('description')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="form-group"> 
            <input type="hidden"  name="student_class_id" value="<?php echo e($student_class_id); ?>">        
        </div>

        
       

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>