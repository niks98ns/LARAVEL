<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Feedback List</h2>
    
    <a href="<?php echo e(route('feedbacks.create', ['student_id' => $_GET['student_id']])); ?>" class="btn btn-success" role="button">Add Feedback</a>   
    <table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">#</th>
          <th scope="col">Month</th>
          <th scope="col">Description</th>
        
       
        </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($feedback->id); ?></td>
            <td><?php echo e($feedback->month); ?></td>
            <td><?php echo e($feedback->description); ?></td>
        
            
            <td>
                <a href="<?php echo e(route('feedbacks.edit', $feedback->id)); ?>" class="btn btn-default">
                    Edit
                </a>

                <form class="form-horizontal pull-right" action="<?php echo e(URL::route('feedbacks.destroy', ['id' => $feedback->id, 'student_id' => $_GET['student_id']])); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE"/>
                    <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                        Delete
                    </button>
                </form> 
               
            
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 


    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>