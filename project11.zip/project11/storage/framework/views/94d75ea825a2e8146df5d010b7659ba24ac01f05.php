<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h2>Session List</h2>
    
    <a href="<?php echo e(route('student_class_students.create', ['student_id' => $_GET['student_id']])); ?>" class="btn btn-success" role="button">Update Student Session</a>        
    <table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">#</th>
          <th scope="col">Student Class</th>
          <th scope="col">Student Name</th>
          
          <th scope="col">School Session </th>
       
      </tr>
    </thead>
    <tbody>
        <?php
        if(!empty($student_class_students)){
        ?>
            <?php $__currentLoopData = $student_class_students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_class_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student_class_student->id); ?></td>
                    <td><?php echo e($student_class_student->student_class->title); ?> 
                        <?php echo e($student_class_student->student_class->section); ?></td>
                    <td><?php echo e($student_class_student->student->first_name); ?> 
                    <?php echo e($student_class_student->student->last_name); ?></td>
                    <td><?php echo e($student_class_student->school_session->session_year); ?></td>
                    <td>
                        <a href="<?php echo e(route('student_class_students.edit', $student_class_student->id)); ?>" class="btn btn-default">
                            Edit
                        </a>

                        <form class="form-horizontal pull-right" action="<?php echo e(URL::route('student_class_students.destroy', ['id' => $student_class_student->id, 'student_id' => $_GET['student_id']])); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="DELETE"/>
                            <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">Delete</button>
                        </form>
                    
                    
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php
        }
        ?>


    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>