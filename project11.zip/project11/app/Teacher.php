<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Teacher extends Model
{
    //
    protected $fillable = [
        'first_name', 'last_name', 'email', 'age', 'experience', 'aadhar_id', 'dob', 'gender', 'address', 'student_class_id'
        
    ];
    
    public function studentClass()
    {
        return $this->hasMany('App\StudentClass');
    }
    
    public function works()
    {
        return $this->belongsTo('App\Work');
    }
    public function teacherStudentclass()
    {
        return $this->hasMany('App\TeacherStudentClass');
    }
}





