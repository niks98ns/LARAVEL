<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Students</h2>    
    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success">Create Student</a><br><br>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Class</th>
                <th scope="col">Email</th>
                <th scope="col">Father Name</th>
                <th scope="col">Mother Name</th>
                <th scope="col">Aadhar ID</th>
                <th scope="col">Age</th>
                <th scope="col">DOB</th>
                <th scope="col">DOA</th>
                <th scope="col">Image</th>
                <th scope="col">Gender</th>
                <th scope="col">Address</th>
                <th scope="col">City</th>
                <th scope="col">State</th>
                <th scope="col">Countary</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
              
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student->id); ?></td>
                    <td><a href="<?php echo e(route('students.show', $student->id)); ?>" >
                        <?php echo e($student->first_name); ?>

                    </td>
                    <td><?php echo e($student->last_name); ?></td>
                    <td><?php echo e($student->student_class->class); ?>

                        <?php echo e($student->student_class->section); ?></td>
                    <td><?php echo e($student->email); ?></td>
                    
                    <td><?php echo e($student->father_name); ?></td>
                    <td><?php echo e($student->mother_name); ?></td>
                    <td><?php echo e($student->aadhar_id); ?></td>
                    <td><?php echo e($student->age); ?></td>
                    <td><?php echo e($student->dob); ?></td>
                    <td><?php echo e($student->doa); ?></td>
                    <td><img class="rounded" src='<?php echo e(asset('storage/'.$student->image)); ?>' height="50px" width="100px"></td>
                    <td><?php echo e($student->gender); ?></td>
                    <td><?php echo e($student->address); ?></td>
                    <td><?php echo e($student->city); ?></td>
                    <td><?php echo e($student->state->name); ?></td>
                    <td><?php echo e($student->countary->name); ?></td>
                    
                    <td>
                        <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary">
                            Edit
                        </a>                       

                        <form class="form-horizontal pull-right" action="<?php echo e(URL::route('students.destroy', [$student->id])); ?>" method="POST" >
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="DELETE"/>
                            <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/multiple_auth/resources/views/students/index.blade.php ENDPATH**/ ?>