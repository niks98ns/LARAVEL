<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Admins</h2>    
    <a href="<?php echo e(route('admins.create')); ?>" class="btn btn-success">Create Admin</a><br><br>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                <th scope="col">Image</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
              
         <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($admin->id); ?></td>
                <td><?php echo e($admin->first_name); ?></td>
                <td><?php echo e($admin->last_name); ?></td>
                <td><?php echo e($admin->email); ?></td>
                <td><img class="rounded" src='<?php echo e(asset('storage/'.$admin->image)); ?>' height="50px" width="100px"></td>
                <td>
                    <a href="<?php echo e(route('admins.edit', $admin->id)); ?>" class="btn btn-primary">
                        Edit
                    </a>                       
    
                    <form class="form-horizontal pull-right" action="<?php echo e(URL::route('admins.destroy', [$admin->id])); ?>" method="POST" >
                            <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE"/>
                        <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/multiple_auth/resources/views/admins/index.blade.php ENDPATH**/ ?>