<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Student</h2><br><br>
    
    
    
    

    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Class</th>
                <th scope="col">Email</th>
                <th scope="col">Father Name</th>
                <th scope="col">Mother Name</th>
                <th scope="col">Aadhar ID</th>
                <th scope="col">Age</th>
                <th scope="col">DOB</th>
                <th scope="col">DOA</th>
                <th scope="col">Image</th>
                <th scope="col">Gender</th>
                <th scope="col">Address</th>
                <th scope="col">City</th>
                <th scope="col">State</th>
                <th scope="col">Countary</th>
            </tr>
        </thead>
        <tbody>
            
                <tr>
                    <td><?php echo e($student->id); ?></td>
                    <td><a href="<?php echo e(route('students.show', $student->id)); ?>" >
                        <?php echo e($student->first_name); ?>

                    </td>
                    <td><?php echo e($student->last_name); ?></td>
                    <td><?php echo e($student->student_class->class); ?>

                        <?php echo e($student->student_class->section); ?></td>
                    <td><?php echo e($student->email); ?></td>
                    
                    <td><?php echo e($student->father_name); ?></td>
                    <td><?php echo e($student->mother_name); ?></td>
                    <td><?php echo e($student->aadhar_id); ?></td>
                    <td><?php echo e($student->age); ?></td>
                    <td><?php echo e($student->dob); ?></td>
                    <td><?php echo e($student->doa); ?></td>
                    <td><img class="rounded" src='<?php echo e(asset('storage/'.$student->image)); ?>' height="50px" width="100px"></td>
                    <td><?php echo e($student->gender); ?></td>
                    <td><?php echo e($student->address); ?></td>
                    <td><?php echo e($student->city); ?></td>
                    <td><?php echo e($student->state->name); ?></td>
                    <td><?php echo e($student->countary->name); ?></td>
                    
                </tr>
            
            
        </tbody>
    </table>
  
<div class="row">
        <h1>
            <div class="col-sm-12"><strong>Student Work:</strong> 
                
        </h1>
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Date</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $student->student_work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student_work->id); ?></td>
                    <td><a href="<?php echo e(route('student_works.show', $student_work->id)); ?>" ><?php echo e($student_work->title); ?></td>
                    <td><?php echo e($student_work->description); ?></td>
                    <td><?php echo e($student_work->created_at); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
        </tbody>
    </table>                      
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/multiple_auth/resources/views/students/show.blade.php ENDPATH**/ ?>