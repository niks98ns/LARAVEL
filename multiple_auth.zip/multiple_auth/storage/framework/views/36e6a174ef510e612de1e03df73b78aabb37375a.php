<div class="text-center text-bold">
    <?php if(count($errors) > 1): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <strong>
                <div class="alert alert-danger">
                    <?php echo e($error); ?>

                </div>
            </strong>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    <?php if(session('success')): ?>
        <strong>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        </strong>  
    <?php endif; ?>      
    
    <?php if(session('error')): ?>
        <strong>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <strong>  
    <?php endif; ?>
    </div>      <?php /**PATH /var/www/html/multiple_auth/resources/views/include/messages.blade.php ENDPATH**/ ?>