<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Student Works List</h2><br><br>

    
    
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $student_works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student_work->id); ?></td>
                    <td><?php echo e($student_work->title); ?></td>
                    <td><?php echo e($student_work->description); ?></td>
                    <td><?php echo e($student_work->created_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('student_works.edit', $student_work->id)); ?>" class="btn btn-primary">
                            Edit
                        </a>                       

                        <form class="form-horizontal pull-right" action="<?php echo e(URL::route('student_works.destroy', [$student_work->id])); ?>" method="POST" >
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="DELETE"/>
                            <button type="submit" class="btn btn-danger" name="button" onclick="return confirm('Are you sure to delete this record?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>                      
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/multiple_auth/resources/views/student_works/show.blade.php ENDPATH**/ ?>