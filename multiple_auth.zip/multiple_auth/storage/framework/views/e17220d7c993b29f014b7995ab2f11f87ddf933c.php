<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-8 offset-md-2">
        <h1>Assign Class & Work</h1>
        <hr>
        <form action="<?php echo e(url('teachers/storestudentclass')); ?>" method="post" enctype="multipart/form-data" data-toggle="validator" role="form">
            <input type="hidden" id="work_id" name="work_id" value="">
  
            <?php echo e(csrf_field()); ?>

            

            <div class="form-group">
                <label for="class" class="col-md-4 control-label">Class</label>
                
                <select name="student_class_id" class="form-control"  data-error="Class Is Required." id="class" placeholder="Class" required>
                            
                    <option value="">----Select-----</option>
                    <?php $__currentLoopData = $student_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student_class->id); ?>"><?php echo e($student_class->class); ?> <?php echo e($student_class->section); ?></option>
                         
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                <div class="text-danger help-block with-errors"></div>
            </div>

            <div class="form-group">
                <label for="title" class="col-md-4 control-label">Work</label>
                
                <select name="title" class="form-control"  data-error="Title Is Required." id="title" placeholder="Title" required>
                            
                    <option value="">----Select-----</option>
                    <?php $__currentLoopData = $student_works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student_work->id); ?>"> <?php echo e($student_work->title); ?></option>
                         
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                <div class="text-danger help-block with-errors"></div>
            </div>

            

            <div class="form-group"> 
                <input type="hidden"  name="teacher_id" value="<?php echo e($teacher_id); ?>">        
            </div>
 
            
            <button type="submit" class="col-md-8 offset-md-2 btn btn-success">Submit</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/multiple_auth/resources/views/teachers/createstudentclass.blade.php ENDPATH**/ ?>