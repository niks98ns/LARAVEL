<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Teacher List</h2><br>

    <a href="<?php echo e(route('teachers.create')); ?>" class="btn btn-success">Create Teacher</a><br><br>
    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success">Add Student</a><br><br>
    <a href="<?php echo e(url('teachers/create/' . $teacher->id)); ?>" class="btn btn-success" role="button">Assign Class & Work</a><br><br>
    
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                
                <th scope="col">Address</th>
                <th scope="col">Age</th>
                <th scope="col">Experience</th>
                <th scope="col">Aadhar ID</th>
                <th scope="col">DOB</th>
                <th scope="col">Gender</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
              
            
                <tr>
                    <td><?php echo e($teacher->id); ?></td>
                    <td><?php echo e($teacher->first_name); ?></td>
                    <td><?php echo e($teacher->last_name); ?></td>
                    <td><?php echo e($teacher->email); ?></td>
                    
                    <td><?php echo e($teacher->address); ?></td>
                    <td><?php echo e($teacher->age); ?></td>
                    <td><?php echo e($teacher->experience); ?></td>
                    <td><?php echo e($teacher->aadhar_id); ?></td>
                    <td><?php echo e($teacher->dob); ?></td>
                    <td><?php echo e($teacher->gender); ?></td>
                    
                </tr>
            
        </tbody>
      </table>                      
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/multiple_auth/resources/views/teachers/show.blade.php ENDPATH**/ ?>